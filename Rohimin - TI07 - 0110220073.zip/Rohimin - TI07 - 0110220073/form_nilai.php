<h1>Form Nilai  Mahasiswa</h1>
<form class="form horizontal"
<form method="GET" action="nilai_siswa.php">
Nama : <input type="text" name="nama" value="" size="30"/><br/>
Mata Kuliah : 
                <select name="matkul">
                <option value="Dasar-Dasar Pemrograman">Dasar-Dasar Pemrograman</option> 
                <option value="Basis Data I">Basis Data I</option>
                <option value="Pemrograman Web">Pemrograman Web</option>
                </select><br/>
Nilai UTS : <input type="text" name="nilai_uts" value="" size="6"/><br/>
Nilai UAS : <input type="text" name="nilai_uas" value="" size="6"/><br/>
Nilai Tugas/Praktikum : <input type="text" name="nilai_tugas" value="" size="6"/><br/>
<input type="submit" value="simpan" name="proses"/>
</form>